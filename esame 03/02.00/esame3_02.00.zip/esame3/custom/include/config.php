<?php

$dbData = [];
$dbData['dns'] = 'mysql:dbname=esame3;host=localhost';
$dbData['user'] = 'esame';
$dbData['pwd'] = 'segreta';

?>
