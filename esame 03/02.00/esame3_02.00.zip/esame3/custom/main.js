$(document).ready(function(){
  $('.ajaxBtn').click(function(){
    alert($(this).val());
  })
});
